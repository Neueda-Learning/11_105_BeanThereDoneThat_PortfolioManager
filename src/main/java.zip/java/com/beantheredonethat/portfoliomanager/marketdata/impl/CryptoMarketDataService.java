package com.beantheredonethat.portfoliomanager.marketdata.impl;

import com.beantheredonethat.portfoliomanager.exception.MarketDataException;
import com.beantheredonethat.portfoliomanager.marketdata.AssetType;
import com.beantheredonethat.portfoliomanager.marketdata.MarketDataRequest;
import com.beantheredonethat.portfoliomanager.marketdata.MarketDataResponse;
import com.beantheredonethat.portfoliomanager.marketdata.MarketDataService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Set;

@Service
public class CryptoMarketDataService implements MarketDataService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public Set<AssetType> supportedAssetTypes() {
        return Set.of(AssetType.CRYPTO);
    }

    @Override
    public MarketDataResponse getCurrentPrice(MarketDataRequest request) {
        if (request == null) throw new MarketDataException("MarketDataRequest cannot be null");

        String id = request.getAssetIdentifier();
        if (id == null || id.isBlank()) {
            // allow symbol fallback
            id = request.getSymbol();
        }
        if (id == null || id.isBlank()) {
            throw new MarketDataException("Crypto asset identifier (coingecko id) is required");
        }

        String currency = request.getCurrency() == null ? "usd" : request.getCurrency();

        String url = String.format("https://api.coingecko.com/api/v3/simple/price?ids=%s&vs_currencies=%s", id, currency);
        try {
            ResponseEntity<String> resp = restTemplate.getForEntity(url, String.class);
            String body = resp.getBody();
            if (body == null) throw new MarketDataException("Empty response from CoinGecko");
            JsonNode root = objectMapper.readTree(body);
            JsonNode node = root.path(id).path(currency);
            if (node.isMissingNode() || node.isNull()) {
                throw new MarketDataException("Missing price for crypto id=" + id + " currency=" + currency);
            }
            BigDecimal price = BigDecimal.valueOf(node.asDouble());
            MarketDataResponse out = new MarketDataResponse();
            out.setPrice(price);
            out.setCurrency(currency);
            out.setTimestamp(Instant.now());
            out.setAssetType(AssetType.CRYPTO);
            out.setProviderId("COINGECKO");
            return out;
        } catch (MarketDataException e) {
            throw e;
        } catch (Exception e) {
            throw new MarketDataException("Failed to fetch crypto price from CoinGecko", e);
        }
    }
}

